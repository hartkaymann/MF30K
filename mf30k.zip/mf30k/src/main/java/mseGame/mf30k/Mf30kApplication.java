package mseGame.mf30k;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mf30kApplication {

	public static void main(String[] args) {
		SpringApplication.run(Mf30kApplication.class, args);
	}

}
