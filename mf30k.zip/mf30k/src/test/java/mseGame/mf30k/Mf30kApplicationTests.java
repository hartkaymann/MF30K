package mseGame.mf30k;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mf30kApplicationTests {

	@Test
	void contextLoads() {
	}

}
